//
//  Pan.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Pan {
    
    //MARK: CHANGE PAN
    
    func changePan(cell: TrackCell, pan: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["pan" : pan]) //set pan value to database
    }
    
}
