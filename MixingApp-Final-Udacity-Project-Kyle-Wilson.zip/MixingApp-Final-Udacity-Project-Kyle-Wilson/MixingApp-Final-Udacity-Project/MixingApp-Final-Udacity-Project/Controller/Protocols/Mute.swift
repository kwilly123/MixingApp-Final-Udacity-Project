//
//  Mute.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Mute {
    
    //MARK: MUTE BUTTON TAPPED
    
    func muteButtonTapped(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was muted!")
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : true]) //set mute value to true for database
    }
    
    //MARK: MUTE BUTTON TAPPED AGAIN
    
    func muteButtonTappedAgain(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was unmuted!")
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : false]) //set mute value to true for database
    }
    
}

extension TracksViewController {
    
    //MARK: CHECK MUTE FOR COLLECTION
    
    func checkMuteTrack(cell: TrackCell) {
        if cell.isMuted == true {
            cell.muteDelegate?.muteButtonTapped(cell: cell)
            cell.audioPlayer?.volume = 0
            cell.muteButton.backgroundColor = .muteBlue
            cell.muteButton.tintColor = .muteBlue
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        } else {
            cell.muteButton.isSelected = false
            cell.audioPlayer?.volume = cell.volumeSlider.value
            cell.muteButton.backgroundColor = .clear
            cell.muteButton.tintColor = .clear
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        }
    }
}
