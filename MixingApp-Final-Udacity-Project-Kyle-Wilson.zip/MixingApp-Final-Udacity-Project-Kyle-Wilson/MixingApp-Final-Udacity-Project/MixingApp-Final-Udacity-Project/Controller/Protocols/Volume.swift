//
//  Volume.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Volume {
    
    //MARK: CHANGE VOLUME

    func changeVolume(cell: TrackCell, volume: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["volume" : volume]) //set volume value to database
    }
    
    //MARK: CHANGE SLIDER VOLUME
    
    func changeSliderVolume(cell: TrackCell, volume: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["volume_slider" : volume]) //set volume slider value to database
    }
    
}
