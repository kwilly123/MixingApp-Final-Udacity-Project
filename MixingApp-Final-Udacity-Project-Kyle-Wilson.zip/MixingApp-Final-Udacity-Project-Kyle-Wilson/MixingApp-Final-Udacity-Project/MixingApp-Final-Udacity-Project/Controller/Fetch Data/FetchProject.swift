//
//  FetchProject.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-30.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import Firebase

extension ProjectSelectViewController {
    
    //MARK: FETCH PROJECT DATA
    
    func fetchProject() {
        print("fetching")
        projects = [] //empty array at the start
        ref.database.reference().child("user_profiles").child(self.userID!).child("projects").observe(.childAdded) { (snapshot) in //observe all projects
            self.sendRef = self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(snapshot.key).child("tracks") //observe each track
            print("KEY: \(snapshot.key)") //project key
            if let dictionary = snapshot.value as? [String: AnyObject] { //access project data with dictionary
                let project = Project()
                project.projectName = dictionary["project_name"] as! String?
                project.creationDate = dictionary["creation_date"] as! String?
                
                self.sendRef.observe(.value) { (snapshot) in //access tracks data within project
                    if let snapshots = snapshot.children.allObjects as? [DataSnapshot] { //get all data objects into an array
                        self.tracks = [] //reset tracks array
                        for snap in snapshots {
                            if let postDict = snap.value as? Dictionary<String, AnyObject> { //access track data with dictionary
                                let track = Track()
                                track.pan = (postDict["pan"] as? NSNumber)?.floatValue //get each value from database
                                track.volume = (postDict["volume"] as? NSNumber)?.floatValue
                                track.volumeSlider = (postDict["volume_slider"] as? NSNumber)?.floatValue
                                track.mute = postDict["mute"] as! Bool?
                                track.solo = postDict["solo"] as! Bool?
                                let eq = EQ()
                                eq.freq1 = (postDict["freq1"] as? NSNumber)?.floatValue
                                eq.freq2 = (postDict["freq2"] as? NSNumber)?.floatValue
                                eq.freq3 = (postDict["freq3"] as? NSNumber)?.floatValue
                                eq.freq4 = (postDict["freq4"] as? NSNumber)?.floatValue
                                eq.gain1 = (postDict["gain1"] as? NSNumber)?.floatValue
                                eq.gain2 = (postDict["gain2"] as? NSNumber)?.floatValue
                                eq.gain3 = (postDict["gain3"] as? NSNumber)?.floatValue
                                eq.gain4 = (postDict["gain4"] as? NSNumber)?.floatValue
                                track.eq = eq
                                self.tracks.append(track) //attach each track to array of tracks
                            }
                            
                        }
                        project.tracks = self.tracks //assign projects tracks to array of tracks
                    }
                }
                
                self.projects.append(project) //append the project to array of projects
                self.projectKeys.append(snapshot.key) //append each project key to the projectKeys array
                print("READING PROJECT KEYS: \(self.projectKeys)")
                
                self.tableView.reloadData()
                print("reloading data")
            }
        }
    }
}
