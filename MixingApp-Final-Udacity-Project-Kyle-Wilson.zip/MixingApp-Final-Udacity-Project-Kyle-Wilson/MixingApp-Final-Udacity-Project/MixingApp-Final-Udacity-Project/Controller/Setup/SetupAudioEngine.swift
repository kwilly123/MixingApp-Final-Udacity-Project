//
//  SetupAudioEngine.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import AVFoundation

extension TracksViewController {
    
    //MARK: SETUP AUDIO ENGINE
    
    func setupAudioEngine() {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.attach(self.mixer)
            self.audioEngine.connect(self.mixer, to: self.audioEngine.outputNode, format: nil)
        }
    }
    
}
