//
//  VC+CollectionDelegateExtension.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-06.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import Firebase

extension TracksViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    //MARK: NUMBER OF SECTIONS
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    //MARK: NUMBER OF ITEMS
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tracks.count
    }
    
    //MARK: CELL FOR ITEM AT
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "track", for: indexPath) as! TrackCell
        
        cell.muteDelegate = self
        cell.soloDelegate = self
        cell.trackDelegate = self
        cell.volumeDelegate = self
        cell.panDelegate = self
        
        cell.trackLabel.text = "Track \n\(indexPath.row + 1)"
        cell.knob.renderer.setPointerAngle(CGFloat(((tracks[indexPath.row].pan! - -1.0) / (1.0 - -1.0)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //set angle according to pan
        cell.knob.value = tracks[indexPath.row].pan! //knob value set to pan
        cell.panValueLabel.text = "\(Int(tracks[indexPath.row].pan! * 100))" //assign label pan value
        cell.volumeSlider.value = tracks[indexPath.row].volumeSlider! //volume slider to volume slider value from database
        cell.isMuted = tracks[indexPath.row].mute! //mutes cell if value is true
        cell.isSoloed = tracks[indexPath.row].solo! //solos cell if value is true
        
        checkSoloTrack(cell: cell, indexPath: indexPath) //check if cell is soloed
        checkMuteTrack(cell: cell) //check if cell is muted
        
        return cell
    }
    
    //MARK: CELL SELECT
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        trackName.text = "Track \(indexPath.row + 1)"
    }
    
}
