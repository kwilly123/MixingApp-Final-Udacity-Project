//
//  LoginViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-14.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn

class LoginViewController: UIViewController {
    
    var userID: String?
    var databaseRef: DatabaseReference!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    //MARK: VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance()?.presentingViewController = self //access the google sign in view
        GIDSignIn.sharedInstance()?.delegate = self //access the delegate for sign in
        activityIndicator.isHidden = true
        print("USER ID: \(String(describing: userID))")
    }
    
    //MARK: VIEWDIDDISAPPEAR
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        activityIndicator.isHidden = false
    }
    
    //MARK: PREPARE TO SEND USERID
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is ProjectSelectViewController {
            let projectSelectVC = segue.destination as? ProjectSelectViewController
            projectSelectVC?.userID = userID
        }
    }
}
