//
//  EQ.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-23.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

//EQ Model
class EQ {
    var freq1: Float?
    var gain1: Float?
    var freq2: Float?
    var gain2: Float?
    var freq3: Float?
    var gain3: Float?
    var freq4: Float?
    var gain4: Float?
}
